﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rigidbody2D;
    private Animator anim;
    public GameObject gameOverText,restartButton,timer;
    // Start is called before the first frame update
    void Start()
    {
        gameOverText.SetActive(false);
        restartButton.SetActive(false);
        QualitySettings.vSyncCount = 0;
		Application.targetFrameRate = 30;
        rigidbody2D = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();

        
        
    }

    // Update is called once per frame
    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
		float vertical = Input.GetAxis("Vertical");
		Vector2 position = rigidbody2D.position;
		position.x = position.x + 8f * horizontal * Time.deltaTime;
		position.y = position.y + 8f * vertical * Time.deltaTime;
		//transform.position = position;
        rigidbody2D.MovePosition(position);

        if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.UpArrow)){
            anim.SetBool("isRunningRight", true);
        }else{
            anim.SetBool("isRunningRight", false);
        }

        if(Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.DownArrow)){
            anim.SetBool("isRunningLeft", true);
        }else{
            anim.SetBool("isRunningLeft", false);
        }
        
    }
    void OnCollisionEnter2D(Collision2D col){
        if(col.gameObject.tag.Equals ("enemy")){

            gameOverText.SetActive(true);
            restartButton.SetActive(true);
            gameObject.SetActive(false);
            timer.SetActive(false);

        }
    }
}
