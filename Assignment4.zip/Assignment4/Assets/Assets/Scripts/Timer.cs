﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    public GameObject gameOverText,restartButton,player;
    int countDownStartValue = 30;
    public Text gameTimer;
    // Start is called before the first frame update
    void Start()
    {
        countDownTimer();
        
    }

    void countDownTimer(){
        if (countDownStartValue > 0){
            TimeSpan spanTime = TimeSpan.FromSeconds(countDownStartValue);
            gameTimer.text = "Timer : " + spanTime.Seconds;
            countDownStartValue--;
            Invoke("countDownTimer", 1.0f);

        }else{

            gameTimer.text = "Time Up!";
            gameOverText.SetActive(true);
            restartButton.SetActive(true);
            gameObject.SetActive(false);
            player.SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {

        
    }
}
