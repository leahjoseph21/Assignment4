﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CoinPicker : MonoBehaviour
{
    private float coin = 0;
    public AudioSource coinSource;

    public TextMeshProUGUI textCoins;

    private void OnTriggerEnter2D(Collider2D other){
        if(other.transform.tag == "coin"){
            coin += 2;
            textCoins.text = coin.ToString();
            coinSource = GetComponent<AudioSource> ();
            coinSource.Play () ;
            Destroy(other.gameObject);

        }
        
    }
}
